#include <stdio.h>
#include <stdlib.h>

main(int nargs, char **args)
{
   printf("SUCCESS");
   exit(0);
}
