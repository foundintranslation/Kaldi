int c2cslave(char c, int i, double d, float f)
{
   if (c == 'y' && i == 2 && d == 2.0 && f == 3.0)
      return(-2);
   return(0);
}
